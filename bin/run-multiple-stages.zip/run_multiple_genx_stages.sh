# ~/bin/bash
export SHELL=$(type -p bash)

# FOLDERS=( "base-short-myopic-current-policies-retire" )

multi_periods() {
    local folder=$1
    echo "${folder}"
    BASE_FOLDER="/Users/gs5183/Documents/MIP/MIP_results_comparison/case_settings/26-zone/atb2023_test_5"
    JULIA_FOLDER="/Users/gs5183/Documents/GenX"
    julia --project=$JULIA_FOLDER "${BASE_FOLDER}/${folder}/Inputs/Inputs_p1/Run.jl"
    python transfer_capacity_forward.py "${BASE_FOLDER}/${folder}/Inputs/Inputs_p1" "${BASE_FOLDER}/${folder}/Inputs/Inputs_p2"

    julia --project=$JULIA_FOLDER "${BASE_FOLDER}/${folder}/Inputs/Inputs_p2/Run.jl"
    python transfer_capacity_forward.py "${BASE_FOLDER}/${folder}/Inputs/Inputs_p2" "${BASE_FOLDER}/${folder}/Inputs/Inputs_p3"

    julia --project=$JULIA_FOLDER "${BASE_FOLDER}/${folder}/Inputs/Inputs_p3/Run.jl"
    python transfer_capacity_forward.py "${BASE_FOLDER}/${folder}/Inputs/Inputs_p3" "${BASE_FOLDER}/${folder}/Inputs/Inputs_p4"

    julia --project=$JULIA_FOLDER "${BASE_FOLDER}/${folder}/Inputs/Inputs_p4/Run.jl"
    python transfer_capacity_forward.py "${BASE_FOLDER}/${folder}/Inputs/Inputs_p4" "${BASE_FOLDER}/${folder}/Inputs/Inputs_p5"

    julia --project=$JULIA_FOLDER "${BASE_FOLDER}/${folder}/Inputs/Inputs_p5/Run.jl"
    python transfer_capacity_forward.py "${BASE_FOLDER}/${folder}/Inputs/Inputs_p5" "${BASE_FOLDER}/${folder}/Inputs/Inputs_p6"

    julia --project=$JULIA_FOLDER "${BASE_FOLDER}/${folder}/Inputs/Inputs_p6/Run.jl"

    python format_results.py "${BASE_FOLDER}/${folder}/Inputs"
    gzip -f "${BASE_FOLDER}/${folder}/Inputs/GenX_results_summary/dispatch.csv"
}
export -f multi_periods
# export FOLDERS

# parallel -j1 multi_periods ::: "${FOLDERS[@]}"
multi_periods "base_short"

# BASE_FOLDER="/Users/gs5183/Documents/MIP/MIP_results_comparison/case_settings/26-zone/genx_inputs"
# for folder in "${FOLDERS[@]}"; do
# julia --project=/Users/gs5183/Documents/GenX "${BASE_FOLDER}/Inputs/Inputs_p1/Run.jl"
# python transfer_capacity_forward.py "${BASE_FOLDER}/Inputs/Inputs_p1" "${BASE_FOLDER}/Inputs/Inputs_p2"

# julia --project=/Users/gs5183/Documents/GenX "${BASE_FOLDER}/Inputs/Inputs_p2/Run.jl"
# python transfer_capacity_forward.py "${BASE_FOLDER}/Inputs/Inputs_p2" "${BASE_FOLDER}/Inputs/Inputs_p3"

# julia --project=/Users/gs5183/Documents/GenX "${BASE_FOLDER}/Inputs/Inputs_p3/Run.jl"